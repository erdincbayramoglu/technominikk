import express from "express";
import cors from "cors";
import bodyParser from "body-parser";
import nodemailer from "nodemailer";
import dotenv from "dotenv";

dotenv.config();
const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(bodyParser.json());

app.post("/api/appointment", async (req, res) => {
  const { name, phone, email, service, date, time, notes } = req.body;
  if (!name || !phone || !service || !date || !time) {
    return res.status(400).json({ success: false, message: "Eksik bilgi." });
  }
  try {
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: { user: process.env.MAIL_USER, pass: process.env.MAIL_PASS }
    });
    await transporter.sendMail({
      from: `"TECHNOMINIKK" <${process.env.MAIL_USER}>`,
      to: process.env.MAIL_TO,
      subject: `Yeni Randevu Talebi - ${name}`,
      text: `Ad: ${name}\nTelefon: ${phone}\nE-posta: ${email || "Belirtilmemiş"}\nHizmet: ${service}\nTarih: ${date} ${time}\nNot: ${notes || "—"}`
    });
    res.json({ success: true, message: "Randevu kaydedildi ve e-posta gönderildi." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Mail gönderilemedi." });
  }
});

app.post("/api/contact", async (req, res) => {
  const { name, email, message } = req.body;
  if (!name || !message) {
    return res.status(400).json({ success: false, message: "Eksik bilgi." });
  }
  try {
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: { user: process.env.MAIL_USER, pass: process.env.MAIL_PASS }
    });
    await transporter.sendMail({
      from: `"TECHNOMINIKK İletişim" <${process.env.MAIL_USER}>`,
      to: process.env.MAIL_TO,
      subject: `Yeni İletişim Mesajı - ${name}`,
      text: `Ad: ${name}\nE-posta: ${email || "Belirtilmemiş"}\nMesaj: ${message}`
    });
    res.json({ success: true, message: "Mesaj kaydedildi ve e-posta gönderildi." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Mesaj gönderilemedi." });
  }
});

app.listen(PORT, () => console.log(`Server çalışıyor: http://localhost:${PORT}`));
